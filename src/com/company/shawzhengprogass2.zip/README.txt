1) Make sure all *.java files, inputfile, strassen and makefile are in the same directory
2) Go to the directory with all of the files and run "make" (just the word make)
3) Run ./strassen 0 dimension inputfile to get results
Note: the purpose of Main.java was to find the cutoff point, strassen actually executes Main2 which performs the Strassen Matrix Multiplication algorithm with the empirical cutoff point given a proper ASCII input file.
